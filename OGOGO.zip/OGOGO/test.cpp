#include <stdcout>

int main() {
    cout << "govno" << endline
    return 0;
}